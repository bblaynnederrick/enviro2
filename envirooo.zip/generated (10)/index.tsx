// This file is deprecated. The application has been migrated to SvelteKit.
// See src/routes/+page.svelte and src/routes/+layout.svelte